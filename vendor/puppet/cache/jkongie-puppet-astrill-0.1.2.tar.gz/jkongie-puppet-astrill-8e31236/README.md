# Astrill Puppet Module for Boxen

Install Astrill, a Plug-and-Play VPN client software for Mac OS X

## Usage

```puppet
include astrill
```

## Required Puppet Modules

* `boxen`

## Development

Write code. Run `script/cibuild` to test it. Check the `script`
directory for other useful tools.
